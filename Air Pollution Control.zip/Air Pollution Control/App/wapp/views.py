from django.shortcuts import render,render_to_response
from . models import FarmerDetails
def index(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('mobile-no') and request.POST.get('city'):
            post = FarmerDetails()
            post.name = request.POST.get('name')
            post.mobile_no = request.POST.get('mobile-no')
            post.city = request.POST.get('city')
            post.save()
    return render(request,'index.html')

def login(request):
    return render(request, 'login.html')
    if request.methode == 'POST':
        x=request.POST.get('mobile-no')
        retrive = FarmerDetails()
        if x in retrive.mobile_no:
            return render(request,'farmerdata.html')


def registerdata(request):
    #data = FarmerDetails.objects.all()
    return render(request,'framerdata.html')
# def login(request):
#     return render(request,'login.html')

# def register(request):
#     if request.method == 'POST':
#         if request.POST.get('name') and request.POST.get('mobile-no') and request.POST.get('city'):
#             post = FarmerDetails()
#             post.name = request.POST.get('title')
#             post.mobile_no = request.POST.get('mobile-no')
#             post.city = request.POST.get('city')
#             post.save()
#             return render(request,'register.html')

# Create your views here.
