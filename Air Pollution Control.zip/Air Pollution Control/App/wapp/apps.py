from django.apps import AppConfig


class WappConfig(AppConfig):
    name = 'wapp'
