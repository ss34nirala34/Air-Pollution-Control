from django.db import models
class FarmerDetails(models.Model):
    name = models.CharField(max_length=50)
    Mobile_number = models.CharField(max_length=12)
    city=models.CharField(max_length=200)

class UsersCropsSaleRequest(models.Model):
    crops_weight = models.CharField(max_length=10)
    sell_Date = models.DateField()
