from django.urls import path,include
from . import views
urlpatterns = [
    path('login/',views.login,name='login'),
    path('',views.index,name="index"),
    path('framerdata/',views.registerdata,name="framerdata"),

    #path('register/',views.register,name='register'),
]