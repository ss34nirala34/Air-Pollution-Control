from django.contrib import admin
#from django.db import models
from .models import FarmerDetails,UsersCropsSaleRequest

admin.site.register(FarmerDetails)
admin.site.register(UsersCropsSaleRequest)