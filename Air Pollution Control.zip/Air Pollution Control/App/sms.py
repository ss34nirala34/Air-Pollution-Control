import nexmo

client = nexmo.Client(key='4be55141', secret='oVgOhyCgWSV60QpG')

response = client.start_verification(
  number="917456893792",
  brand="Nexmo",
  code_length="4")

if response["status"] == "0":
  print("Started verification request_id is %s" % (response["request_id"]))
else:
  print("Error: %s" % response["error_text"])